
<center>
<div class="row" >
    
    <div class="col-lg-4"></div>
    <div class="col align-self-center">
        <form method="POST">
    	<div class="form-group">
    	    
    		<input type="text" name="nama_warung" class="form-control" placeholder="Nama Warung">
    	</div>
    	<div class="form-group">
    		
    		<input type="text" name="nama_penjual" class="form-control" placeholder="Nama Penjual">
    	</div>
    	<button type="submit" class="tbadd" name="submit" value="1!1">Simpan</button>
        </form>
    </div>
    <div class="col-lg-4"></div>
</div>
</center>